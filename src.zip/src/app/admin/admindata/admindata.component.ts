import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admindata',
  templateUrl: './admindata.component.html',
  styleUrls: ['./admindata.component.css']
})
export class AdmindataComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
