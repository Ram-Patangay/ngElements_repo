import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-settingdata',
  templateUrl: './settingdata.component.html',
  styleUrls: ['./settingdata.component.css']
})
export class SettingdataComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
